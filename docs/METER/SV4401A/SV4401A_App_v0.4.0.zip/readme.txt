SV4401A firmware v0.4.0 features:
1. Fixed the bug that the device cannot sleep or the trace is no longer refreshed after the device is woken up;
2. Improved S11 trace noise;
3. Optimized the TDR function, when the TDR mode is turned on, other traces will be closed, and exiting the TDR mode will return to the original state;
4. Add TDR trace peak search function;
5. The SWR value is accurate to three decimal places;
6. Multilingual: Support French and Russian.


SV4401A  v0.4.0 固件特性：
1. 修复了设备无法休眠或唤醒后迹线不再刷新的bug；
2. 修复了S11测量结果曲线不够平滑的问题；
3. 优化了TDR功能，TDR模式下其他迹线将会关闭，退出TDR模式可恢复原来的状态；
4. 增加TDR迹线峰值搜索功能；
5. SWR数值精确到小数点后三位；
6. 英文版增加法语、俄语两种语言。