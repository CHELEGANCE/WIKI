SV6301A firmware v0.5.1 features:
1. Added signal generator function: open it by [STIMULUS] -> [SIGNAL GENERATOR];
2. More trace formats: MOD Z, conductance, susceptance, parallel R, parallel X, series C, series L, parallel C, parallel L;
3. Added Max hold and Min hold function: press and hold any blank part of the screen to call up the menu;
4. Logarithmic sweeping supported: open it by [STIMULUS] -> [SET FREQUENCY] -> [LOG SWEEP];
5. The abscissa becomes the timeline in TDR mode;
6. Added auto save function: open it by [STORAGE] -> [AUTO SAVE];
7. Fixed the bug of the VSWR analysis function under SWEEP ANALYSIS;
8. Auto scale supported: open it by press and hold the trace control box to call up the menu and choose [Auto scale];


SV6301A  v0.5.1 固件特性：
1. 新增信号发生器功能，在【激励】->【信号发生器】中打开；
2. 新增多种迹线格式：阻抗模值、电导图、电纳图、并联电阻、并联电抗、串联电容、串联电感、并联电容、并联电感；
3. 新增最大保持、最小保持功能（仅针对幅频对数及驻波比），通过长按屏幕空白处弹出菜单进行设置；
4. 增加对数扫描功能。在【激励】->【频率设置】->【对数扫描】中打开；
5. TDR模式下，横坐标改为时间轴；
6. 增加自动保存功能，在【存储】->【自动保存】中打开；
7. 修复了扫描分析中VSWR分析模块的BUG；
8. 新增自动刻度功能：长按迹线控制框弹出菜单并选择【自动刻度】；