SV4401A firmware v0.3.1 features:
-------------------------------------------------------------------------------------
1. Fixed the bug that the measurement result was displayed as NAN;
2. Fixed the bug of TDR trace abnormality;
3. Fixed the bug of RTC time;
4. SV4401A can be recognized as U-disk in Linux and MacOS systems;
5. Enable the TTL UART port to allow the host computer to communicate with SV4401A by TTL UART;
6. When browsing pictures, you can switch pictures by the LEFT & RIGHT buttons, and press CTRL to exit browsing;
7. The scanning speed increased by 30% for the frequencies below 140MHz, and increased 100% for the frequencies below 1MHz;
8. When only the S11 channel is enabled, the scanning speed is further increased to 500 points/s;
9. Added "PRESET" button to restore the device to its default settings.


SV4401A  v0.3.1 固件特性：
-------------------------------------------------------------------------------------
1. 修复了测量结果数值显示为NAN的bug；
2. 修复了TDR迹线异常的bug；
3. 修复了时间显示错乱的bug;
4. U-disk模式下增加对LINUX和MACOS的支持；
5. 开放TTL_UART接口，允许上位机通过TTL_UART与SV4401A通信；
6. 浏览图片时可通过左/右按键切换图片，按CTRL可退出浏览；
7. 140MHz以下频段扫描速度提升30%，1MHz以下频段扫描速度提升100%；
8. 当仅开启S11通道时，扫描速度进一步提升，最高可达500点/秒；
9. 新增“出厂设置”按钮，可将设备恢复为默认设置。