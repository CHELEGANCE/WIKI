JNCRadio_VNA 3G firmware v1.1.0 features
-------------------------------------------------------------------------------------------
1. Scan points increased to 1001;
2. When only channel S11 is turned on, the acquisition and processing of channel S21 will be automatically stopped to speed up scanning;
3. Corrected the sign of group delay value, and improved the group delay noise;
4. Fixed the bug of TDR mode;
5. When 'save' or 'recall' command is sent with no arguments, the status of all save/recall slots will be printed;
6. Dark mode supportment: copy 'dark_mode.txt' to the root directory of the VNA to enable dark mode;
7. Optimized the display format of the frequency range on the main screen;
8. Add the battery level icon.


Firmware upgrade method
-------------------------------------------------------------------------------------------
1. Unzip 'JNCRadio_VNA_3G_firmware_v1.1.0.zip' to get the file named 'vnaApp.bin';
2. Connect your VNA to your Windows PC's USB port using Type-C USB socket on the device;
3. Press the middle button and keep it down while powering up the device, the LCD displays the prompt, indicating that the boot-loader is active;
4. At PC side, the device will act as a disk drive, which should appear in File Explorer;
5. Copy 'vnaApp.bin' into the root directory of that disk to overwrite the original file;
6. Copy 'dark_mode.txt' into the root directory of the disk if you want to enable dark mode;
7. Restart the device to check the frimware vision on the startup screen.