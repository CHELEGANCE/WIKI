JNCRadio_VNA 3G firmware v1.3.0 features
-------------------------------------------------------------------------------------------
1. New feature: add preset menu button;
2. New feature: set date and time on device;
3. Fixed bug of TDR mode;
4. Menu structure optimized;


Firmware upgrade method
-------------------------------------------------------------------------------------------
1. Unzip 'JNCRadio_VNA_3G_firmware_v1.3.0.zip' to get the file named 'vnaApp.bin';
2. Connect your VNA to your Windows PC's USB port using Type-C USB socket on the device;
3. Press the middle button and keep it down while powering up the device, the LCD displays the prompt, indicating that the boot-loader is active;
4. At PC side, the device will act as a disk drive, which should appear in File Explorer;
5. Copy 'vnaApp.bin' into the root directory of that disk to overwrite the original file;
6. Restart the device to check the frimware vision on the startup screen.